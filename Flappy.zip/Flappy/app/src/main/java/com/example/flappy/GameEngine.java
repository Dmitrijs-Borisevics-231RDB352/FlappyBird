package com.example.flappy;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class GameEngine {

    public int gameState = 0;
    public Bird bird;
    public BackgroundImage background;

    private List<Pipe> pipes = new ArrayList<>();
    private int pipeSpawnTimer = 0;
    private int pipeSpawnInterval = 250;

    private boolean gameOverHandled = false;

    public GameEngine() {
        bird = new Bird();
        background = new BackgroundImage();
    }

    public void updateAndDrawableBackgroundImage(Canvas canvas) {
        background.update();
        if (background.getX() <= -AppConstants.getBitmapBank().getBackgroundWidth()) {
            background.setX(0);
        }

        canvas.drawBitmap(AppConstants.getBitmapBank().getBg2(), background.getX(), background.getY(), null);
        canvas.drawBitmap(AppConstants.getBitmapBank().getBg2(),
                background.getX() + AppConstants.getBitmapBank().getBackgroundWidth(),
                background.getY(), null);
    }

    public void updateAndDrawBird(Canvas canvas) {
        if (gameState == 1) {
            bird.update();
        }
        canvas.drawBitmap(AppConstants.getBitmapBank().getBird(), bird.getX(), bird.getY(), null);
    }

    public void updateAndDrawPipes(Canvas canvas) {
        if (gameState != 1) return;

        pipeSpawnTimer++;
        if (pipeSpawnTimer >= pipeSpawnInterval) {
            pipeSpawnTimer = 0;
            pipes.add(new Pipe(
                    AppConstants.SCREEN_WIDTH,
                    AppConstants.SCREEN_HEIGHT,
                    AppConstants.getBitmapBank().getPipeTop(),
                    AppConstants.getBitmapBank().getPipeBottom(),
                    8
            ));
        }

        Iterator<Pipe> iter = pipes.iterator();
        while (iter.hasNext()) {
            Pipe pipe = iter.next();
            pipe.update();
            pipe.draw(canvas);

            if (pipe.isOffScreen()) {
                iter.remove();
            }

            if (pipe.collidesWith(
                    bird.getX(), bird.getY(),
                    AppConstants.getBitmapBank().getBirdWidth(),
                    AppConstants.getBitmapBank().getBirdHeight())) {
                handleGameOver();
            }
        }

        if (bird.getY() + AppConstants.getBitmapBank().getBirdHeight() > AppConstants.SCREEN_HEIGHT || bird.getY() < 0) {
            handleGameOver();
        }
    }

    private void handleGameOver() {
        if (gameOverHandled) return;

        gameOverHandled = true;
        gameState = 2;

        Context context = AppConstants.getContext();
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            Intent intent = new Intent(context, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            context.startActivity(intent);
        }, 1500);
    }
}