package com.example.flappy;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import java.util.Random;

public class Pipe {

    private int x;
    private int gapHeight = 900;
    private int screenHeight;
    private int velocity;

    private int upperPipeHeight;
    private int lowerPipeY;

    private Bitmap pipeTopBitmap;
    private Bitmap pipeBottomBitmap;

    private int width;

    public Pipe(int startX, int screenHeight, Bitmap pipeTopBitmap, Bitmap pipeBottomBitmap, int velocity) {
        this.x = startX;
        this.screenHeight = screenHeight;
        this.pipeTopBitmap = pipeTopBitmap;
        this.pipeBottomBitmap = pipeBottomBitmap;
        this.velocity = velocity;

        this.width = pipeTopBitmap.getWidth();

        Random rand = new Random();
        int minPipeHeight = pipeTopBitmap.getHeight() / 2;
        int maxPipeHeight = screenHeight - gapHeight - minPipeHeight;
        this.upperPipeHeight = rand.nextInt(maxPipeHeight - minPipeHeight) + minPipeHeight;

        this.lowerPipeY = upperPipeHeight + gapHeight;
    }

    public void update() {
        x -= velocity;
    }

    public void draw(Canvas canvas) {
        canvas.drawBitmap(pipeTopBitmap, x, upperPipeHeight - pipeTopBitmap.getHeight(), null);
        canvas.drawBitmap(pipeBottomBitmap, x, lowerPipeY, null);
    }

    public boolean isOffScreen() {
        return x + width < 0;
    }

    public boolean collidesWith(int birdX, int birdY, int birdWidth, int birdHeight) {
        Rect birdRect = new Rect(birdX, birdY, birdX + birdWidth, birdY + birdHeight);

        Rect upperPipeRect = new Rect(x, upperPipeHeight - pipeTopBitmap.getHeight(), x + width, upperPipeHeight);
        Rect lowerPipeRect = new Rect(x, lowerPipeY, x + width, lowerPipeY + pipeBottomBitmap.getHeight());

        return Rect.intersects(birdRect, upperPipeRect) || Rect.intersects(birdRect, lowerPipeRect);
    }

    public int getX() {
        return x;
    }
}