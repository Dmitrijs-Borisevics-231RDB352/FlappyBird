package com.example.flappy;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class BitmapBank {

    Bitmap bg2;
    Bitmap bird;
    Bitmap pipeTop;
    Bitmap pipeBottom;

    public BitmapBank(Resources resources) {
        Bitmap originalBg = BitmapFactory.decodeResource(resources, R.drawable.bg2);
        bg2 = scaleImage(originalBg);

        Bitmap originalBird = BitmapFactory.decodeResource(resources, R.drawable.bird);
        int birdWidth = originalBird.getWidth() / 6;
        int birdHeight = originalBird.getHeight() / 6;
        bird = Bitmap.createScaledBitmap(originalBird, birdWidth, birdHeight, false);

        Bitmap originalPipeTop = BitmapFactory.decodeResource(resources, R.drawable.pipe_top);
        int pipeTopWidth = originalPipeTop.getWidth() / 3;
        int pipeTopHeight = originalPipeTop.getHeight() / 3;
        pipeTop = Bitmap.createScaledBitmap(originalPipeTop, pipeTopWidth, pipeTopHeight, false);

        Bitmap originalPipeBottom = BitmapFactory.decodeResource(resources, R.drawable.pipe_bottom);
        int pipeBottomWidth = originalPipeBottom.getWidth() / 3;
        int pipeBottomHeight = originalPipeBottom.getHeight() / 3;
        pipeBottom = Bitmap.createScaledBitmap(originalPipeBottom, pipeBottomWidth, pipeBottomHeight, false);
    }

    public Bitmap getBird() {
        return bird;
    }

    public int getBirdWidth() {
        return bird.getWidth();
    }

    public int getBirdHeight() {
        return bird.getHeight();
    }

    public Bitmap getBg2() {
        return bg2;
    }

    public int getBackgroundWidth() {
        return bg2.getWidth();
    }

    public int getBackgroundHeight() {
        return bg2.getHeight();
    }

    public Bitmap getPipeTop() {
        return pipeTop;
    }

    public Bitmap getPipeBottom() {
        return pipeBottom;
    }

    public Bitmap scaleImage(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();

        float ratio = (float) width / height;
        int scaledWidth = (int) (ratio * AppConstants.SCREEN_HEIGHT);

        return Bitmap.createScaledBitmap(bitmap, scaledWidth, AppConstants.SCREEN_HEIGHT, false);
    }
}