package com.example.flappy;

public class Bird {

    private int birdX, birdY, velocity;
    public Bird() {
        birdX = AppConstants.SCREEN_WIDTH / 5;
        birdY = AppConstants.SCREEN_HEIGHT / 2;
        velocity = 0;
    }

    public int getVelocity() {
        return velocity;
    }

    public void setVelocity(int i) {
        this.velocity = i;
    }

    public int getX() {
        return birdX;
    }

    public int getY() {
        return birdY;
    }

    public void setX(int birdX) {
        this.birdX = birdX;
    }

    public void setY(int birdY) {
        this.birdY = birdY;
    }

    public void update() {
        velocity += AppConstants.gravity;
        birdY += velocity;
    }
}
